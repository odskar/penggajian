package com.example.penggajian;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	Button proses, hapus;
	EditText nama, gaji;
	TextView nmp, gp, tun, bpjs, jamsos, bersih;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		nama = (EditText)findViewById(R.id.nama);
		gaji = (EditText)findViewById(R.id.gaji);
		hapus = (Button)findViewById(R.id.hapus);
		hapus.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				nmp= (TextView)findViewById(R.id.nmp);
				gp= (TextView)findViewById(R.id.gp);
				tun= (TextView)findViewById(R.id.tun);
				bpjs= (TextView)findViewById(R.id.bpjs);
				jamsos= (TextView)findViewById(R.id.jamsos);
				bersih= (TextView)findViewById(R.id.bersih);
				nama = (EditText)findViewById(R.id.nama);
				gaji = (EditText)findViewById(R.id.gaji);
				
				nmp.setText("");
				gp.setText("");
				tun.setText("");
				bpjs.setText("");
				jamsos.setText("");
				bersih.setText("");
				nama.setText("");
				gaji.setText("");
			}
		});
			
			
			
		
		return true;
	}
	public void hitung (View v){
		String namapegawai;
		namapegawai= nama.getText().toString();
		int inputan=Integer.parseInt(gaji.getText().toString());
		int gajipokok= inputan;
		int tunjangan= inputan*10/100;
		int bpjsp= inputan*2/100;
		int jamsostek= inputan*5/100;
		int gajibersih= (gajipokok+tunjangan)-(bpjsp+jamsostek);
		
		nmp= (TextView)findViewById(R.id.nmp);
		gp= (TextView)findViewById(R.id.gp);
		tun= (TextView)findViewById(R.id.tun);
		bpjs= (TextView)findViewById(R.id.bpjs);
		jamsos= (TextView)findViewById(R.id.jamsos);
		bersih= (TextView)findViewById(R.id.bersih);
		
		nmp.setText(namapegawai+"");
		gp.setText(gajipokok+"");
		tun.setText(tunjangan+"");
		bpjs.setText(bpjsp+"");
		jamsos.setText(jamsostek+"");
		bersih.setText(gajibersih+"");
	}
}
